/*
 *	Loesungsvorschlag u03a SS23
 *  Daniela Heiss
 *  12.04.2023
 */

#include "cWindrad.h"

int main() {
	cWindrad wr1("Windstrom23", 131.8, 320.0, 48.3, 8.72),
		wr2("Watt4Watt78", 192.7, 730.0, 56.76, 5.80),
		wr3;

	cout << "Teil a)\n" << endl;
	wr1.ausgabe();
	wr2.ausgabe();
	wr3.ausgabe();

	//Teil b)

	cout << "\nTeil b)\n" << endl;

	cWindrad windraeder[1000];
	int i = 0;
	int count = 0;

	while (windraeder[i].getType() != "-") {		//Die Schleife wird bei der Eingabe von '-' nicht sofort beendet, gibt elegantere Loesungen die cin Eingaben abgfangen
		
		windraeder[i].eingabe();	
			
		if (windraeder[i].getType() != "-") {
			count++;
		}

		cout << "\nKontrolle:" << endl;
		windraeder[i].ausgabe();

		cout << "\n" << endl;
	}


	cout << "Windraeder" << endl;
	cout << "Tabelle mit " << count<< " Zeilen" << endl;	//Keine richtig formatierte Tabelle, aber der Wille war da
	
	for (int i = 0; i < count; i++) {
		windraeder->ausgabe();
	}

	return 0;
}