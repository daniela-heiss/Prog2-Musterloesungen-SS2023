#pragma once
#include <string>
#include <iostream>
using namespace std;

class cWindrad
{
private:
	string type;
	double height;
	double power;
	double longitude;
	double latitude;
	void korrHoehe();

public:
	cWindrad(string = "--", double = 130.0, double = 0.0, double = 0.0, double = 0.0);
	void eingabe();
	void ausgabe();

	string getType();

};

