#include "cWindrad.h"

void cWindrad::korrHoehe()
{
	if (height < 0) {
		height = 120.0;
	}
	else if (latitude <= 53.2 && longitude >= 6.7 && height > 130) {
		height = 130.0;
	}
	else if (height > 200) {
		height = 200;
	}
}

cWindrad::cWindrad(string type, double height, double power, double longitude, double latitude) //Diesmal Verwendung von this, da ich die Parameter genauso wie unsere Attribute benannt habe
{
	this->type = type;	
	this->height = height;
	this->power = power;
	this->longitude = longitude;
	this->latitude = latitude;

	korrHoehe();	//Aufruf der Hoehenkorrektur im Konstruktor, damit kein Objekt mit falschen Werten instanziiert werden kann
}

void cWindrad::eingabe()	//Hier werden keine Fehler abgefangen, wie z.B. nicht gueltige Laengen- und Breitengrade, was man jedoch ergaenzen koennte
{
	cout << "Neues Windrad wird erstellst" << endl;		//Formatierung kann natuerlich schoener gestaltet werden
	cout << "Typ: "; cin >> type; 
	cout << "Hoehe: "; cin >> height; 
	cout << "Leistung: "; cin >> power; 
	cout << "Laengengrad: "; cin >> longitude; 
	cout << "Breitengrad: "; cin >> latitude; cout << endl;

	korrHoehe(); //Auch hier wird korrHoehe aufgerufen um sicherzustellen, dass kein Windrad mit falschem Hoehenwert exisiteren kann
}

void cWindrad::ausgabe()
{
	cout << "Typ: " << type << ", Hoehe: " << height << ", Leistung: " << power << ", Geographische Position: (" << longitude << ", " << latitude << ")" << endl;
}

string cWindrad::getType()
{
	return type;
}
