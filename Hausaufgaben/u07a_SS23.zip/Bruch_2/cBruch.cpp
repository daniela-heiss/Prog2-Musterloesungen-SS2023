#include "cBruch.h"

cBruch::cBruch(int zaehler_in, int nenner_in)
{
	zaehler = zaehler_in;
	nenner = nenner_in == 0 ? 1 : nenner_in;

	if (nenner < 0) {
		zaehler *= -1;
		nenner *= -1;
	}	//Falls der Nenner negativ ist, werden Zaehler und Nenner negiert, sodass die negative Zahl im Zaehler steht

	kuerzen();
}

void cBruch::ausgabe() {
	cout << zaehler << "/" << nenner << " (" << (double)zaehler / nenner << ")" << endl; //Gleitkommazahlrechnung durch double cast um den Gleitkomma-Wert des Bruches herauszubekommen
}

double cBruch::ggT(int x, int y) {
	if (y == 0)
		return x;
	else return ggT(y, x % y);	//ggT-Variante mit Modulo
}

void cBruch::kuerzen() {
	int temp = zaehler == 0 ? 1 : ggT(zaehler < 0 ? zaehler * -1 : zaehler, nenner < 0 ? nenner * -1 : nenner);	//Falls der Zaehler 0 ist, ist der ggT 1, und falls Zaehler oder Nenner negativ sind, wird der Betrag ausgerechnet
	zaehler /= temp;
	nenner /= temp;
}

cBruch::cBruch(const cBruch& bruch_in) {		//Kopier-Konstruktor
	zaehler = bruch_in.zaehler;
	nenner = bruch_in.nenner;
}

//Freund-Funktionen
cBruch add(cBruch a, cBruch b) {
	cBruch c;

	c.zaehler = ((a.zaehler * b.nenner) + (b.zaehler * a.nenner));
	c.nenner = a.nenner * b.nenner;

	c.kuerzen();
	return c.nenner == 0 ? NULL : c;	//Falls bei der Rechnung ein Bruch berechnet wird, welcher durch 0 teilt, wird 0 als Wert zur�ckgegeben
}

cBruch subt(cBruch a, cBruch b) {
	cBruch c;

	c.zaehler = ((a.zaehler * b.nenner) - (b.zaehler * a.nenner));
	c.nenner = a.nenner * b.nenner;

	c.kuerzen();
	return c.nenner == 0 ? NULL : c;	//Falls bei der Rechnung ein Bruch berechnet wird, welcher durch 0 teilt, wird 0 als Wert zur�ckgegeben
}

cBruch mul(cBruch a, cBruch b) {
	cBruch c;

	c.zaehler = a.zaehler * b.zaehler;
	c.nenner = a.nenner * b.nenner;

	c.kuerzen();
	return c.nenner == 0 ? NULL : c;	//Falls bei der Rechnung ein Bruch berechnet wird, welcher durch 0 teilt, wird 0 als Wert zur�ckgegeben
}

cBruch div(cBruch a, cBruch b) {
	cBruch c;

	c.zaehler = a.zaehler * b.nenner;
	c.nenner = a.nenner * b.zaehler;

	c.kuerzen();
	return c.nenner == 0? NULL : c;	//Falls bei der Rechnung ein Bruch berechnet wird, welcher durch 0 teilt, wird 0 als Wert zur�ckgegeben
}

int vergleich(cBruch a, cBruch b) {
	double temp_a = (double)a.zaehler / a.nenner;
	double temp_b = (double)b.zaehler / b.nenner;

	if (temp_a < temp_b) {
		return -1;
	}
	else if (temp_a == temp_b) {
		return 0;
	}
	else if (temp_a > temp_b) {
		return 1;
	}
}

void tausch(cBruch& a, cBruch& b) {
	cBruch temp = a;

	a = b;
	b = temp;
}

void sortier(cBruch cArr[], int len) {
	for (int n = len; n > 1; n--) {
		for (int i = 0; i < n - 1; i++) {
			if (vergleich(cArr[i], cArr[i + 1]) == 1) {
				tausch(cArr[i], cArr[i + 1]);
			}
		}
	}
}