// Dani, 2021

#include "cBruch.h"

int main() {

	cBruch helpme;
	cBruch cBArr[8] = { cBruch(3,6),
						cBruch(21,-7),
						cBruch(8,-10),
						cBruch(-4,6),
						cBruch(-8,-13),
						cBruch(-4,5),
						cBruch(21,37),};

	cout << "Ausgabe des Arrays:" << endl; 

	for (int i = 0; i <= 7; i++) {
		cBArr[i].ausgabe();
	}

	cout << "\nRechnungen:" << endl;

	helpme = add(cBArr[0], cBArr[1]);
	cout << "Ergebnis Addition: "; helpme.ausgabe();

	helpme = subt(cBArr[2], cBArr[3]);
	cout << "Ergebnis Subtraktion: "; helpme.ausgabe();

	helpme = mul(cBArr[4], cBArr[5]);
	cout << "Ergebnis Multiplikation: "; helpme.ausgabe();

	helpme = div(cBArr[6], cBArr[7]);
	cout << "Ergebnis Division: "; helpme.ausgabe();

	sortier(cBArr, 8);

	cout << "\nAusgabe nach der Sortierung:" << endl; 

	for (int i = 0; i <= 7; i++) {
		cBArr[i].ausgabe();
	}

	return 0;
}