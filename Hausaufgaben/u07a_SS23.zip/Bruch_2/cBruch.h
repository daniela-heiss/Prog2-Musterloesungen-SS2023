#pragma once
#include <iostream>
using namespace std;

class cBruch
{
private:
	int zaehler;
	int nenner;
	void kuerzen();
	double ggT(int, int);

	//Freund-Funktionen
	friend cBruch add(cBruch, cBruch);
	friend cBruch subt(cBruch, cBruch);
	friend cBruch mul(cBruch, cBruch);
	friend cBruch div(cBruch, cBruch);
	friend int vergleich(cBruch, cBruch);
	friend void tausch(cBruch&, cBruch&);
	friend void sortier(cBruch cArr[], int);

public:
	cBruch(int = 0, int = 1);	//Konstruktor
	cBruch(const cBruch&);		//Kopier-Konstruktor
	void ausgabe();
};
