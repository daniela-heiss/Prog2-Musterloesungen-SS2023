#include "cPunkt.h"

void cPunkt::korrPunkt()
{
	if (x > 10) {
		x = 10;
	}
	else if (x < -10) {
		x = -10;
	}

	if (y > 10) {
		y = 10;
	}
	else if (y < -10) {
		y = -10;
		}
}

cPunkt::cPunkt(double x_in, double y_in)
{
	x = x_in;
	y = y_in;

	korrPunkt();
}

void cPunkt::ausgabe()
{
	cout << "(" << x << "/" << y << ")" << endl;
}

double cPunkt::getX()
{
	return x;
}

double cPunkt::getY()
{
	return y;
}

