#include "cDreieck.h"

double cDreieck::umfangD()
{
	return (ab + bc + ca);
}

double cDreieck::flaecheD()
{
	double s = umfangD() / 2;

	return (sqrt(s * (s - ab) * (s - bc) * (s - ca)));
}

cDreieck::cDreieck(cPunkt a_in, cPunkt b_in, cPunkt c_in): a(a_in), b(b_in), c(c_in)
{
	ab = (sqrt(pow(b.getX() - a.getX(), 2) + pow(b.getY() - a.getY(), 2)));	//Strecken
	bc = (sqrt(pow(c.getX() - b.getX(), 2) + pow(c.getY() - b.getY(), 2)));
	ca = (sqrt(pow(a.getX() - c.getX(), 2) + pow(a.getY() - c.getY(), 2)));
}

cDreieck::cDreieck(double a_x, double a_y, double b_x, double b_y, double c_x, double c_y) : a(a_x, a_y), b(b_x, b_y), c(c_x, c_y)
{
	ab = (sqrt(pow(b.getX() - a.getX(), 2) + pow(b.getY() - a.getY(), 2)));	//Strecken
	bc = (sqrt(pow(c.getX() - b.getX(), 2) + pow(c.getY() - b.getY(), 2)));
	ca = (sqrt(pow(a.getX() - c.getX(), 2) + pow(a.getY() - c.getY(), 2)));
}

void cDreieck::ausgabe()
{
	cout << "Punkt a: "; a.ausgabe();
	cout << "Punkt b: "; b.ausgabe();
	cout << "Punkt c: "; c.ausgabe();
	cout << "Umfang: " << umfangD() << endl;
	cout << "Flaeche: " << flaecheD() << endl;
}
