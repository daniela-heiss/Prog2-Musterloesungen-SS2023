#pragma once
#include "cPunkt.h"

class cDreieck
{
private:
	cPunkt a;
	cPunkt b;
	cPunkt c;

	double ab;
	double bc;
	double ca;

	double umfangD();
	double flaecheD();

public:
	cDreieck(cPunkt = { 0.0,1.0 }, cPunkt = { 1.0,0.0 }, cPunkt = { 0.0, 0.0 });	//Universalkonstruktor
	cDreieck(double, double, double, double, double, double);	//Ueberladung, bzw. andere Moeglichkeit den Konstruktor aufzubauen

	void ausgabe();


};

