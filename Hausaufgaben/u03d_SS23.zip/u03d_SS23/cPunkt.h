#pragma once
#include <iostream>
using namespace std;

class cPunkt
{
private:
	double x;
	double y;
	void korrPunkt();
public:
	cPunkt(double = 0.0, double = 0.0);
	void ausgabe();

	double getX();	//get-Funktionen damit wir im Dreieck auf die Werte x und y zugreifen koennen
	double getY();
};

