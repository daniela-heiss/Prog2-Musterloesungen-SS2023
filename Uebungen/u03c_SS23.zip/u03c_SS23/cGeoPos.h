#pragma once
#include <iostream>
using namespace std;

class cGeoPos
{
private:
	double longi;
	double lati;
	void korrPos();
public:
	cGeoPos(double = 48.79, double = 8.17);
	void setGeoPos(double, double);
	void printGeoPos();

	double getLati();
	double getLongi();
};

