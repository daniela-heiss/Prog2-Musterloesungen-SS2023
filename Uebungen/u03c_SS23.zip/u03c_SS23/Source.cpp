/*	Loesungsvorschlag u03c - Windrad mit Aggregation im Sommersemester 2023
 *	Daniela Heiss
 *	26.04.23
 */

#include "cWindrad.h"

int main() {
	cWindrad wr1("WindWork2Stay", 151.8, 342.0, 48.3, 8.72),
		wr2("Watt4Watt4U", 192.7, 820.0, 57.66, 5.37),
		wr3;


	cout << "Teil a)\n" << endl;
	wr1.ausgabe();
	wr2.ausgabe();
	wr3.ausgabe();

	//Teil b)

	cout << "\nTeil b)\n" << endl;

	cWindrad windraeder[1000];
	int i = 0;
	int count = 0;

	while (windraeder[i].getType() != "-") {		//Die Schleife wird bei der Eingabe von '-' nicht sofort beendet, gibt elegantere Loesungen die cin Eingaben abgfangen

		windraeder[i].eingabe();

		if (windraeder[i].getType() != "-") {
			count++;
		}
		else if (windraeder[i].getType() == "-") {
			break;
		}

		cout << "\nKontrolle:" << endl;
		windraeder[i].ausgabe();

		cout << "\n" << endl;
	}


	cout << "Windraeder" << endl;
	cout << "Tabelle mit " << count << " Zeilen" << endl;	//Keine richtig formatierte Tabelle, aber der Wille war da

	for (int i = 0; i < count; i++) {
		windraeder->ausgabe();
	}

}