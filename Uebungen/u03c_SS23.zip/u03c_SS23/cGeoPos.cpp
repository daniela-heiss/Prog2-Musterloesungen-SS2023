#include "cGeoPos.h"

void cGeoPos::korrPos()		//ACHTUNG: Keine korrekte Umrechnung, ich kappe nur die Werte bei der jeweiligen Begrenzung
{
	if (lati > 90) {
		lati = 90;
	}
	else if (lati < -90) {
		lati = -90;
	}

	if (longi > 180) {
		longi = 180;
	}
	else if (longi < -180) {
		longi = -180;
	}
}

cGeoPos::cGeoPos(double lati_in , double longi_in)
{
	lati = lati_in;
	longi = longi_in;

	korrPos();
}

void cGeoPos::setGeoPos(double lati_in, double longi_in)
{
	lati = lati_in;
	longi = longi_in;

	korrPos();
}

void cGeoPos::printGeoPos()
{
	cout << "(" << lati << ", " << longi << ")";
}

double cGeoPos::getLati()
{
	return lati;
}

double cGeoPos::getLongi()
{
	return longi;
}
