#pragma once
#include <string>
#include <iostream>
#include "cGeoPos.h"
using namespace std;

class cWindrad
{
private:
	string type;
	double height;
	double power;
	cGeoPos pos;
	void korrHoehe();

public:
	cWindrad(string = "--", double = 130.0, double = 0.0, double = 0.0, double = 0.0);
	void eingabe();
	void ausgabe();

	string getType();

};

