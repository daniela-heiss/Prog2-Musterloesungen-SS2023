#include "cMotorrad.h"

cMotorrad::cMotorrad(string bez_in, int rad_in, int zyl_in, double ps_in)
{
	bez = bez_in;
	rad = rad_in;
	zyl = zyl_in;
	ps = ps_in;
}

void cMotorrad::ausgabe()
{
	cout << "Motorrad der Bezeichnung: " << bez << ", Raeder: " << rad << ", Zylinder: " << zyl << ", Antriebsleistung: " << ps << endl;
}
