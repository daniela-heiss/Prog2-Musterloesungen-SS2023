#pragma once
#include <string>
#include <iostream>
using namespace std;

class cMotorrad
{
private:
	string bez;
	int rad;
	int zyl;
	double ps;
public:
	cMotorrad(string = "--", int = 2, int = 1, double = 14.8);
	void ausgabe();
};

