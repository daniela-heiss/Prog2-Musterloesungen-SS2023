/*
 * Loesungsvorschlag u02a SS23 mit zwei Varianten
 * Daniela Heiss
 * 12.04.2023
 */

#include "cMotorrad.h"	//iostream und string muessen hier nicht inkludiert werden, da diese bereits ueber die cMotorrad Header Datei inkludiert werden

int main() {
	/*cMotorrad rad1;
	cMotorrad rad2("Motorrad1", 2, 4, 40);
	cMotorrad rad3("Motorrad2", 3, 3, 30);
	cMotorrad rad4("Motorrad3", 2, 2, 20);
	cMotorrad rad5("Motorrad4", 2, 4, 60);

	rad1.ausgabe();
	rad2.ausgabe();
	rad3.ausgabe();
	rad4.ausgabe();
	rad5.ausgabe();
	*/

	cMotorrad motorraeder[] = { cMotorrad(), cMotorrad("Motorrad1", 2, 4, 40), cMotorrad("Motorrad2", 3, 3, 30), cMotorrad("Motorrad3", 2, 2, 20), cMotorrad("Motorrad4", 2, 4, 60) };

	for (cMotorrad x : motorraeder) {	//for-each loop
		x.ausgabe();
	}

	return 0;
}

