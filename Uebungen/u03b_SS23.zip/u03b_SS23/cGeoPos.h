#pragma once
#include <iostream>
#include <iomanip>	//Wird fuer die Tabellen (setw) benoetigt
using namespace std;

#define NUM_WIDTH 8	//globale Konstanten fuer die Tabellenbreiten
#define TAB_WIDTH 12

class cGeoPos
{
private:
	double longi;
	double lati;

	void korrPos();	//ausgelagerte Korrektur-Methode, sodass die set-Methode nur Werte setzt

public:
	cGeoPos(double lati_in = 0.0, double longi_in = 0.0);

	void setGeoPos(double lati_in, double longi_in);
	void ausgabe();
	void ausgabeTabelle();

	double getLati();

};

