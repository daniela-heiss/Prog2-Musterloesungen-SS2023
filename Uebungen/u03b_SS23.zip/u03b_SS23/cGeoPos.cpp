#include "cGeoPos.h"

void cGeoPos::korrPos()		//ACHTUNG: Keine korrekte Umrechnung, ich kappe nur die Werte bei der jeweiligen Begrenzung
{
	if (lati > 90) {
		lati = 90;
	}
	else if (lati < -90) {
		lati = -90;
	}

	if (longi > 180) {
		longi = 180;
	}
	else if (longi < -180) {
		longi = -180;
	}
}

cGeoPos::cGeoPos(double lati_in, double longi_in)
{
	lati = lati_in;
	longi = longi_in;

	korrPos();
}

void cGeoPos::setGeoPos(double lati_in, double longi_in)
{
	lati = lati_in;
	longi = longi_in;

	korrPos();
}

void cGeoPos::ausgabe()
{
	cout << "Laengengrad: " << setw(NUM_WIDTH) << longi << "Breitengrad: " << setw(NUM_WIDTH) << lati << endl;
}

double cGeoPos::getLati()
{
	return lati;
}

void cGeoPos::ausgabeTabelle()
{
	cout << setw(TAB_WIDTH) << longi << " |" << setw(TAB_WIDTH) << lati << " |" << endl;
}
