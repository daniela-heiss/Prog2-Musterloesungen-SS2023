#include "cBaum.h"

void cBaum::korrHoehe()
{
	double lati = pos.getLati();

	if (height < 1) {
		height = 1;
	}
	else if ((lati >= 60 || lati <= -60) && height > 7.5) {	//Werte koennen durch korrPos() nicht ueber oder unter 90 liegen, also brauchen wir nur eine Begrenzung
		height = 7.5;
	}
	else if ((((lati >= 30 && lati <= 60) || (lati <= -30 && lati >= -60)) && height > 35)) {
		height = 35;
	}
	else if ((lati <= 30 && lati >= -30) && height > 68) {
		height = 68;
	}
}

cBaum::cBaum(string type_in, double height_in, cGeoPos pos_in) : pos(pos_in)
{
	type = type_in;
	height = height_in;

	korrHoehe();
}

cBaum::cBaum(string type_in, double height_in, double lati_in, double longi_in) : pos(lati_in, longi_in)
{
	type = type_in;
	height = height_in;

	korrHoehe();
}

void cBaum::eingabe()
{
	double lati_help;
	double longi_help;

	cout << "\nEingabe eines neuen Baumes: " << endl;
	cout << "Baumart: "; cin >> type;
	if (type == "-") { return; }
	cout << "Hoehe: "; cin >> height;
	cout << "Breitengrad: "; cin >> lati_help;
	cout << "Laengengrad: "; cin >> longi_help;

	pos.setGeoPos(lati_help, longi_help);
	korrHoehe();
}

void cBaum::ausgabe()
{
	cout << "Baumart: " << left << setw(NAME_WIDTH) << type << "Hoehe: " << setw(NUM_WIDTH) << height;     
	pos.ausgabe();
}

void cBaum::ausgabeTabelle()
{
	cout << " |" << setw(TAB_WIDTH + NUM_WIDTH) << type << " |" << setw(NUM_WIDTH) << height << " |";           //Ausgabeformat f�r tabellarische Darstellung der Daten
	pos.ausgabeTabelle();
	cout << " -------------------------------------------------------------";
	cout << endl;
}

string cBaum::getType()
{
	return type;
}
