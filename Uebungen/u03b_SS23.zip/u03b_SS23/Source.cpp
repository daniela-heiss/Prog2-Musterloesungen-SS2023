/* Loesungsvorschlag u03b
 * Daniela Heiss
 * 19.04.2023
 */


#include "cGeoPos.h"
#include "cBaum.h"

//Funktion statt Methode
void tabellenkopf()
{
	cout << " -------------------------------------------------------------";
	cout << endl;
	cout << " |";
	cout.width(TAB_WIDTH + NUM_WIDTH);
	cout << "Baumart";
	cout << " |";
	cout.width(NUM_WIDTH);
	cout << "Hoehe";
	cout << " |";
	cout.width(TAB_WIDTH);
	cout << "Laengengrad";
	cout << " |";
	cout.width(TAB_WIDTH);
	cout << "Breitengrad";
	cout << " |" << endl;
	cout << " |-----------------------------------------------------------|" << endl;
}


int main() {
	//Aufgabenteil a)
	cBaum baum1("Fichte", 111.1, 47.3, 212.72),
		baum2("Baobab", 57.3, 62.81, -14.63),
		baum3;

	baum1.ausgabe();
	baum2.ausgabe();
	baum3.ausgabe();

	//Aufgabenteil b)

	int i = 0;

	cBaum baeume[1000];

	while (true) {
		baeume[i].eingabe();
		if (baeume[i].getType() == "-") { break; }
		baeume[i].ausgabe();
		i++;
	}

	tabellenkopf();
	i = 0;

	while (baeume[i].getType() != "-") {
		baeume[i].ausgabeTabelle();
		i++;
	}

	//Aufgabenteil c)

	cBaum baeume2[1000] = { cBaum("Baum1", 20, 30, 40), cBaum("Baum2", 6, 60, 90), cBaum("Baum3", 3, 79, 60), cBaum("Baum4", 30, -40, 70), cBaum("Baum5", 50, -10, 60) };

	i = 5;

	while (true) {
		baeume2[i].eingabe();
		if (baeume2[i].getType() == "-") { break; }
		baeume2[i].ausgabe();
		i++;
	}

	tabellenkopf();
	i = 0;

	while (baeume2[i].getType() != "-") {
		baeume2[i].ausgabeTabelle();
		i++;
	}

	return 0;
}