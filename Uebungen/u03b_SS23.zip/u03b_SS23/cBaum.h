#pragma once
#include <string>
#include "cGeoPos.h"
using namespace std;

#define NAME_WIDTH 12

class cBaum
{
private:
	string type;
	double height;
	cGeoPos pos;

	void korrHoehe();

public:
	cBaum(string type_in = "--", double height_in = 10.0, cGeoPos pos_in = { 48.79, 8.17 });					//Zwei Konstruktor-Ueberladungen
	cBaum(string type_in, double height_in, double lati_in, double longi_in);

	void eingabe();
	void ausgabe();			//Zwei Ausgabemethoden fuer die unterschiedlichen Formatierungen
	void ausgabeTabelle();
	string getType();

};

