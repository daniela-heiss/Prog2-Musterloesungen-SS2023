/*	Loesungsvorschlag u04a - Vererbung Fahrrad im Sommersemester 2023
 *	Daniela Heiss
 *	26.04.2023
 */

#include "cLastdreirad.h"
#include "cRikscha.h"
#include "cMountainbike.h"
#include "cEinrad.h"

int main() {
	cLastdreirad hauruck;
	cRikscha einergehtnochrein;
	cMountainbike downhillstar;
	cEinrad obenbleiben;

	// Mit den Objekten spielen:
	cout << "Radzahl des Lastdreirads: " << hauruck.get_radzahl() << endl;
	cout << "Radzahl der Rikscha: " << einergehtnochrein.get_radzahl() << endl;
	cout << "Radzahl des Mountainbikes: " << downhillstar.get_radzahl() << endl;
	cout << "Radzahl des Einrads: " << obenbleiben.get_radzahl() << endl;
	cout << "Mountainbike nach 500 meter downhill, spass = "
		<< downhillstar.downhill(500) << endl;
	cout << "Mountainbike bekommt einen Steinschlag" << endl;
	downhillstar.steinschlag();
	cout << "Mountainbike nach Steinschlag, spass = " << downhillstar.downhill(0)
		<< endl;
	cout << "Mountainbike bekommt einen Steinschlag" << endl;
	downhillstar.steinschlag();
	cout << "Mountainbike nach Steinschlag, spass = " << downhillstar.downhill(0)
		<< endl;
	cout << "Ende" << endl;

	return 0;
}