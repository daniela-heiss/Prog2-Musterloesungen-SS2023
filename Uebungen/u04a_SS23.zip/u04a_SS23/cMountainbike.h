#pragma once
#include "cFreizeitrad.h"
class cMountainbike :
    public cFreizeitrad
{
    void schimpfen();
public:
    cMountainbike(int = 2, double = 1.3, double = 100.0);
    double downhill(int hoehendifferenz);
    void steinschlag();
};

