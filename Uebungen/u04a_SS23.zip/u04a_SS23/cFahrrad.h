#pragma once
#include <iostream>		//Benoetigt ab cMountainbike
using namespace std;

class cFahrrad
{
	int radzahl;
	double luftdruck;
public:
	cFahrrad(int = 0, double = 0.0);
	int get_radzahl();
	double get_luftdruck();
	double aufpumpen(double druckplus);
};

