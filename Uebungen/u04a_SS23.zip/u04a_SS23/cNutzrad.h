#pragma once
#include "cFahrrad.h"
class cNutzrad :
    public cFahrrad
{
    double ertrag;
public:
    cNutzrad(int = 0, double = 0.0, double = 0.0);
    double kassieren(double einkommen);
    double wartungmachen(double kosten);
};

