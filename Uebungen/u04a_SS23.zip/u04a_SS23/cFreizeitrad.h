#pragma once
#include "cFahrrad.h"
class cFreizeitrad :
    public cFahrrad
{
protected:
    double spass;
public:
    cFreizeitrad(int = 0, double = 0.0, double = 0.0);
    void abschliessen(bool disziplin);
    double geniessen(double genuss);
};

