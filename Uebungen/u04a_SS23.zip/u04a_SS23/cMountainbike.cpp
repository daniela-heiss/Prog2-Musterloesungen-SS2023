#include "cMountainbike.h"

void cMountainbike::schimpfen()
{
	cout << "Schon wieder ein Stein, macht keinen Spass mehr" << endl;
}

cMountainbike::cMountainbike(int radzahl_in, double luftdruck_in, double spass_in) : cFreizeitrad(radzahl_in, luftdruck_in, spass_in)
{
}

double cMountainbike::downhill(int hoehendifferenz)
{
	spass += 10 * hoehendifferenz;
	return spass;
}

void cMountainbike::steinschlag()
{
	if (spass - 2000 < 0) {
		spass = 0;
	}
	else {
		spass -= 2000;
	}

	if (spass == 0) {
		schimpfen();
	}
}

