#pragma once
#include "cFreizeitrad.h"
class cEinrad :
    public cFreizeitrad
{
public:
    cEinrad(int = 1, double = 2.3, double = 200.0);
    double geniessen(double genuss);
};

