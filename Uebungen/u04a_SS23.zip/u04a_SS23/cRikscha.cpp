#include "cRikscha.h"

cRikscha::cRikscha(int radzahl_in, double luftdruck_in, double ertrag_in, int fahrgastzahl_in) : cNutzrad(radzahl_in, luftdruck_in, ertrag_in)
{
	fahrgastzahl = fahrgastzahl_in;
}

int cRikscha::einsteigen(int rein)
{
	if (fahrgastzahl + rein > 7) {
		fahrgastzahl = 7;
	}
	else {
		fahrgastzahl += rein;
	}
	return fahrgastzahl;
}

int cRikscha::aussteigen(int raus)
{
	if (fahrgastzahl - raus < 0) {
		fahrgastzahl = 0;
	}
	else {
		fahrgastzahl -= raus;
	}
	return fahrgastzahl;
}
