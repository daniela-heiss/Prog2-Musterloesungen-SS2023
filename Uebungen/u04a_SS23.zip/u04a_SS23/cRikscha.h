#pragma once
#include "cNutzrad.h"
class cRikscha :
    public cNutzrad
{
    int fahrgastzahl;
public:
    cRikscha(int = 4, double = 2.7, double = 620.0, int = 1);
    int einsteigen(int rein);
    int aussteigen(int raus);
};

