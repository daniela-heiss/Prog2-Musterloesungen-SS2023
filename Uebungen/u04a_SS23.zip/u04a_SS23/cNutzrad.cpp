#include "cNutzrad.h"

cNutzrad::cNutzrad(int radzahl_in, double luftdruck_in, double ertrag_in) : cFahrrad(radzahl_in, luftdruck_in)
{
	ertrag = ertrag_in;
}

double cNutzrad::kassieren(double einkommen)
{
	ertrag += einkommen;
	return ertrag;
}

double cNutzrad::wartungmachen(double kosten)
{
	ertrag -= kosten;
	return ertrag;
}
