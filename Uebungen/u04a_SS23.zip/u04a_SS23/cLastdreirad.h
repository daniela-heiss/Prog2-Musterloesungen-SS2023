#pragma once
#include "cNutzrad.h"
class cLastdreirad :
    public cNutzrad
{
    double nutzlast;
public:
    cLastdreirad(int = 3, double = 3.8, double = 380.0, double = 72.50);
    double zuladen(double lastplus);
    double abladen(double lastminus);
};

