#pragma once
#include <iostream>
using namespace std;

#define SEGMENTS 42

class cLageSkala
{
	double unterGrenze;
	double oberGrenze;
	double aktVal;

	double getSegment() const;
	bool checkNum(double u, double o, double a);
public:
	cLageSkala(double untergrenze_in = 0.0, double obergrenze_in = 1.0, double aktval_in = 0.5);
	void ausgabe();

	cLageSkala operator ++ (void);
	cLageSkala operator -- (void);

	friend ostream& operator << (ostream& o, const cLageSkala& obj);
	friend istream& operator >> (istream& i, cLageSkala& obj);
};

