// u08g cLageSkala
// 01.06.2023
// Dani

#include "cLageSkala.h"

int main() {
	cLageSkala s1;

	s1.ausgabe();
	cout << s1 << endl;

	for (int i = 0; i < 3; i++) {
		++s1;
	}
	
	//s1.ausgabe(); //Zusatzausgabe
	cout << s1 << endl;

	cin >> s1;
	s1.ausgabe();
	cout << s1 << endl;

	--s1;
	//s1.ausgabe();
	cout << s1 << endl;

	return 0;
}