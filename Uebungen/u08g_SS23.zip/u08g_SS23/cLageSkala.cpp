#include "cLageSkala.h"

double cLageSkala::getSegment() const
{
    return (oberGrenze - unterGrenze) / SEGMENTS;
}

bool cLageSkala::checkNum(double u, double o, double a)
{
    if (u < o && a > u && a < o) {
        return true;
    }
    else {
        return false;
    }
}

cLageSkala::cLageSkala(double untergrenze_in, double obergrenze_in, double aktval_in)
{   
    if (checkNum(untergrenze_in, obergrenze_in, aktval_in)){
        unterGrenze = untergrenze_in;
        oberGrenze = obergrenze_in;
        aktVal = aktval_in;
    }
    else {
        unterGrenze = 0.0;
        oberGrenze = 1.0;
        aktVal = 0.5;
    }
}

void cLageSkala::ausgabe()
{
    cout << "Untergrenze, Obergrenze, Aktval: " << unterGrenze << ", " << oberGrenze << ", " << aktVal << endl;
}

cLageSkala cLageSkala::operator++(void)
{
    if (aktVal + getSegment() < oberGrenze) {
        aktVal += getSegment();
    }
    else {
        cout << "Fehler beim Inkrementieren" << endl;
    }
    return *this;
}

cLageSkala cLageSkala::operator--(void)
{
    if (aktVal - getSegment() > unterGrenze) {
        aktVal -= getSegment();
    }
    else {
        cout << "Fehler beim Dekrementieren" << endl;
    }
    return *this;
}

ostream& operator<<(ostream& o, const cLageSkala& obj)
{
    double intervall = obj.unterGrenze;

    o << "|";
    for (; intervall <= obj.oberGrenze; intervall += obj.getSegment()) {
        if (obj.aktVal >= intervall && obj.aktVal < intervall + obj.getSegment()) {
            o << "*";
        }
        else {
            o << "-";
        }
    }
    o << "|";

    return o;
}

istream& operator>>(istream& i, cLageSkala& obj)
{
    double u_help, o_help, a_help;

    cout << "Geben Sie eine Untergrenze ein: ";
    i >> u_help;
    cout << endl << "Geben Sie eine Obergrenze ein: ";
    i >> o_help;
    cout << endl << "Geben Sie den aktuellen Wert ein: ";
    i >> a_help; cout << endl;

    if (obj.checkNum(u_help, o_help, a_help)) {
        obj.unterGrenze = u_help;
        obj.oberGrenze = o_help;
        obj.aktVal = a_help;
    }
    else {
        cout << "Fehler bei der Eingabe, Standardwerte werden verwendet" << endl;
        obj.unterGrenze = 0.0;
        obj.oberGrenze = 1.0;
        obj.aktVal = 0.5;
    }

    return i;
}
